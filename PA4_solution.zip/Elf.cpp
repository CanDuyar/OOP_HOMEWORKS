#include "Elf.h"
#include "Creature.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

// default constructor
Elf::Elf() : Creature(3,10,10) {
	/*Body Intentionally Empty*/
}

//constructor with paramaters
Elf::Elf(int newStrength, int newHit) : Creature(3,newStrength, newHit) {
	/* Body Intentionally Empty */
}

//returns amount of damage
int Elf::getDamage(){
	int damage = Creature::getDamage();
	cout << getSpecies() << " attacks for " << damage << " points!" << endl;

	 if (rand() % 10 == 0){
		 damage *= 2;
		 cout << "xxx Elf's Double Magical Attack xxx" << endl;
	 }
	 cout << "Amount of damage: " << damage << endl;

	return damage;
 }

 string Elf::getSpecies(){
	if(getType() == 3)
		return "Elf";
}
}