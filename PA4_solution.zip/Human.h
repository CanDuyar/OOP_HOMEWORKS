
#ifndef HUMAN_H
#define HUMAN_H

#include <iostream>
#include "Creature.h"

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

class Human : public Creature { // Human class which is derived from Creature class
public:
	Human(); //default constructor
	Human(int newStrength, int newHit); //constructor with parameters
	int getDamage(); //returns amount of damage
	string getSpecies();
};

}

#endif 