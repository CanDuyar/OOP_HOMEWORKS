
#include "Cyberdemon.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{ //definition of GTU namespace

// default constructor
Cyberdemon::Cyberdemon() : Demon(1,10,10){
}

//constructor with paramaters
Cyberdemon::Cyberdemon(int newStrength, int newHit) : Demon(1,newStrength, newHit) {
	/* Body Intentionally Empty */
}

//returns amount of damage
int Cyberdemon::getDamage(){
    int damage = Demon::getDamage();
    cout << getSpecies() << " attacks for " << damage << " points!" << endl;
     cout << "Amount of damage: " << damage << endl;
    return damage;
 }

 string Cyberdemon::getSpecies(){
	if(getType() == 1)
		return "Cyberdemon";
}

}