#include "Human.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

//default constructor
Human::Human() : Creature(0,10,10) {
	/* Body Intentionally Empty */
}

//constructor with parameters
Human::Human(int newStrength, int newHit) : Creature(0,newStrength, newHit) {
	/* Body Intentionally Empty */
}

//returns amount of damage
int Human::getDamage() {
	int damage = Creature::getDamage();
	cout << getSpecies() << " attacks for " << damage << " points!" << endl;
	 cout << "Amount of damage: " << damage << endl;
    return damage ;

}

string Human::getSpecies(){
	if(getType() == 0)
		return "Human";
}

}