
#ifndef DEMON_H
#define DEMON_H

#include "Creature.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{ //definition of GTU namespace

class Demon : public Creature { // Demon class which is derived from Creature class
public:
	Demon(); // default constructor
	Demon(int newType, int newStrength, int newHit); //constructor with paramaters
	int getDamage(); //returns amount of damage
};

}

#endif