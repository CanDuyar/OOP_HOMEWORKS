
#include "Balrog.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

// default constructor
Balrog::Balrog() : Demon(2,10,10){ 
	/* Body Intentionally Empty */
}

//constructor with parameters
Balrog::Balrog(int newStrength, int newHit) : Demon(2,newStrength, newHit) { 
	/* Body Intentionally Empty*/
}

//returns amount of damage
int Balrog::getDamage(){
	int damage = Demon::getDamage();

 // balrogs are fast so they get to attack twice
	 int balrog_damage = (rand() % getStrength()) + 1;
   	 cout << getSpecies() << " attacks for " << damage << " points!" << endl;
	 damage += balrog_damage;
   	 cout << "Balrog speed attack points -> " << balrog_damage << endl;
   	 cout << "Amount of damage: " << damage << endl;
 
    return damage;
}

string Balrog::getSpecies(){
	if(getType() == 2)
		return "Balrog";
}


}
