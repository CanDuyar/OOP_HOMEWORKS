
#ifndef CYBERDEMON_H
#define CYBERDEMON_H

#include <iostream>
#include "Demon.h"

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

class Cyberdemon : public Demon { //Cyberdemon class which is derived from Demon
public:
	Cyberdemon(); // default constructor
	Cyberdemon(int newStrength, int newHit); //constructor with paramaters
	int getDamage(); //returns amount of damage
	string getSpecies();

};


}

#endif