#include <iostream>
#include "Creature.h"
#include "Demon.h"
#include "Balrog.h"
#include "Cyberdemon.h"
#include "Elf.h"
#include "Human.h"
using namespace GTU;
using namespace std;

/* CAN DUYAR - 171044075 */

int main() {


    srand(time(NULL));

    Human h(20, 30);
    Cyberdemon c(60, 70);
    Balrog b(80, 90);
    Elf e(40, 50);


    for (int i = 0; i < 10; i++){
        h.getDamage();
        c.getDamage();
        b.getDamage();
        e.getDamage();
        cout << endl;
    }

    cout << endl;

}