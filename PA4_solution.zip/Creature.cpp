
#include <iostream>
#include "Creature.h"

using namespace std;

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

Creature::Creature() : strength(10),hitpoints(10),type(0){
	/* Body Intentionally Empty*/
}

Creature::Creature(int newType, int newStrength, int newHit) : type(newType),strength(newStrength),hitpoints(newHit){
	/* Body Intentionally Empty*/
}

int Creature::getDamage(){

	int damage;
	// All creatures inflict damage which is a
	// random number up to their strength
	damage = (rand() % strength) + 1;
	

 	return damage;
}

string Creature::getSpecies(){
	if(getType() == 0)
		return "Human";
}

int Creature::getStrength()const {
	return strength;
}

int Creature::getHitpoints()const {
	return hitpoints;
}

int Creature::getType()const {
	return type;
}

void Creature::setStrength(int newStrength) {
	this->strength = newStrength;
}

void Creature::setHitpoints(int newHit) {
	this->hitpoints = newHit;
}

void Creature::setType(int newType) {
	this->type = newType;
}

}