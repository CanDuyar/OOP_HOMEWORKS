
#include "Demon.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{

// default constructor
Demon::Demon(){
 /*Body Intentionally Empty*/
}

//constructor with paramaters
Demon::Demon(int newType,int newStrength, int newHit) : Creature(newType,newStrength, newHit) {
	/* Body Intentionally Empty */
}

//returns amount of damage
int Demon::getDamage(){
	
// demons can inflict damage of 50 with a 5% chance	
int damage = Creature::getDamage();
	if ((rand() % 100) < 5){
	 damage += 50;
	 cout << "Demonic attack points -> +50 " << endl;

	}

	return damage;
}

}