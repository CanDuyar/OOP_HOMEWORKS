
#ifndef CREATURE_H
#define CREATURE_H

#include <string>
using namespace std;

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace

class Creature { // Creature class
public:
	Creature(); //default constructor
	Creature(int newType, int newStrength, int newHit); // constructor with parameters
	//GETTERS
	int getDamage();
	int getStrength() const;
	int getHitpoints() const;
	string getSpecies(); //helper function which returns the creature type
	int getType()const;
	//SETTERS
	void setStrength(const int newStrength);
	void setHitpoints(const int newHit);     
	void setType(const int newType);
private:
	int strength; //member data which stores the strength
	int hitpoints; //member data which stores the hitpoints
	int type; //member data which defines the type
};

}


#endif