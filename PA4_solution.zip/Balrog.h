#ifndef BALROG_H
#define BALROG_H

#include "Demon.h"
#include <iostream>

/* CAN DUYAR - 171044075 */

namespace GTU{ // definition of GTU namespace
	class Balrog : public Demon { // Balrog class which is derived from Demon class.
	public:
		Balrog(); // default constructor
		Balrog(int newStrength, int newHit); //constructor with parameters
		int getDamage(); //returns amount of damage
		string getSpecies();
};

}

#endif