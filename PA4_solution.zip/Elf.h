#ifndef ELF_H
#define ELF_H

#include "Creature.h"

/* CAN DUYAR - 171044075 */

namespace GTU{ //definition of GTU namespace

class Elf : public Creature { // Elf class which is derived from Creature class
public:
	Elf(); // default constructor
	Elf(int newStrength, int newHit); //constructor with paramaters
	int getDamage(); //returns amount of damage
	string getSpecies();
};

}

#endif